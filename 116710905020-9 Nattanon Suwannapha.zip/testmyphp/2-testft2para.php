<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP wuth two parameters</title>
</head>
<body>
    <H2>PHP wuth two parameters</H2>
    <?php
        function addFunction($sum1, $sum2) {
            $sum = $sum1 + $sum2;
            echo "Sum of the two numbers is : $sum";
        }

        addFunction(10,20);
    ?>
</body>
</html>