<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writing PHP function with parameters</title>
</head>
<body>
    <H2>Writing PHP Function which return value</H2>
    <?php
        function addFunction($num1, $num2) {
            $sum = $num1 + $num2;
            return $sum;
        }

        $return_value = addFunction(10,20);
        
        echo "Returning value from the function : $return_value";
    ?>
</body>
</html>