<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Arguments by Reference</title>
</head>
<body>
    <H2>PHP Arguments by Reference</H2>
    <?php
        function addFive(&$num) :void {
            $num += 5;
        }

        function addSix(&$num) :void {
            $num += 6;
        }

        $orignum = 10;
        addFive( $origum );

        echo "Original Value is $orignum<br />";

        addSix( $orignum);
        echo "Original Value is $orignum<br />";

    ?>
</body>
</html>