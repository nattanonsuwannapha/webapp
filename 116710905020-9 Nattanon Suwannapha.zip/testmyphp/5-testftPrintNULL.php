<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writing PHP Function which return value</title>
</head>
<body>
    <H2>Writing PHP Function which return value</H2>
    <?php
        function printME($param = Null) {
            print $param;
        }
        printMe("This is Test");
        printMe();
        printMe("<br />This is Test");
        printMe();printMe();
    ?>
</body>
</html>