<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writing PHP Funtion  with parameters</title>
</head>
<body>
<h2>Exercise-5</h2>
    <?php
    function test($n) {
 
    return $n % 3 == 0 || $n % 7 == 0;
 
    }
    echo "<pre>";
    var_dump(test(3));
    var_dump(test(14));
    var_dump(test(12));
    var_dump(test(37));
    echo "</pre>";
    ?>
   
</body>
</html>